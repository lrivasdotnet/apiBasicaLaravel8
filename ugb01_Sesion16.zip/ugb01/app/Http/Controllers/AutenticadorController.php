<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AutenticadorController extends Controller
{
    //
    public function registrar(Request $request)
    {
        $validarDatos = $request->validate([
            "name" => "required|max:100",
            "email" => "required|email|unique:users",
            "password" => "required|confirmed"
        ]);

        $validarDatos["password"] = Hash::make($request->password);
        //Crear o Registrar el nuevo usuario
        $usuario = User::create($validarDatos);
        //Generar Token
        $tokenAcceso = $usuario->createToken('authToken')->accessToken;
        return response([
            "usuario" => $usuario,
            "access_token" => $tokenAcceso
        ]);
    }

    public function logearse(Request $request)
    {
        $loginDatos = $request->validate([
            "email" => "required|email",
            "password" => "required"
        ]);

        if (!Auth::attempt($loginDatos)) {
            return response([
                "peticion" => "200",
                "mensaje" => "El usuario o password no es correcto"
            ]);
        } else {
            //Si existe
            $usuario = User::where("email", $request->email)->first();
            $tokenAcceso = $usuario->createToken('authToken')->accessToken;
            return response([
                "peticion" => "200",
                "mensaje" => "Usuario logeado: " . $usuario->email,
                "access_token" => $tokenAcceso

            ]);
        }
    }
}
